CREATE DATABASE  IF NOT EXISTS `steamify` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `steamify`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: steamify
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `genre_to_song_metric_mapping`
--

DROP TABLE IF EXISTS `genre_to_song_metric_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre_to_song_metric_mapping` (
  `game_genre_id` int NOT NULL,
  `danceability_bucket` int NOT NULL,
  `energy_bucket` int NOT NULL,
  `acousticness_bucket` int NOT NULL,
  `instrumentalness_bucket` int NOT NULL,
  PRIMARY KEY (`game_genre_id`),
  CONSTRAINT `genre_to_song_metric_mapping_ibfk_1` FOREIGN KEY (`game_genre_id`) REFERENCES `game_genre` (`game_genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre_to_song_metric_mapping`
--

LOCK TABLES `genre_to_song_metric_mapping` WRITE;
/*!40000 ALTER TABLE `genre_to_song_metric_mapping` DISABLE KEYS */;
INSERT INTO `genre_to_song_metric_mapping` VALUES (1,2,3,1,2),(2,2,2,2,2),(3,2,1,2,3),(4,2,2,2,3),(5,3,2,2,2),(6,2,1,2,3),(7,2,2,2,2),(8,2,2,2,2),(9,2,2,2,2),(10,2,2,2,3),(11,2,3,1,2),(12,2,2,2,2),(13,2,2,2,2),(14,2,2,2,2),(15,2,1,2,3),(16,3,3,1,2),(17,2,2,2,2),(18,2,2,2,2),(19,2,2,2,2),(20,2,2,2,2),(21,3,3,1,2),(22,2,2,2,2),(23,2,1,2,3),(24,2,1,2,3),(25,2,3,1,2),(26,2,1,2,3);
/*!40000 ALTER TABLE `genre_to_song_metric_mapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 21:40:44
