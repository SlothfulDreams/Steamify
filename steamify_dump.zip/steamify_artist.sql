CREATE DATABASE  IF NOT EXISTS `steamify` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `steamify`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: steamify
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist` (
  `artist_id` int NOT NULL,
  `artist_name` varchar(255) NOT NULL,
  PRIMARY KEY (`artist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (1,'1900Rugrat'),(2,'1900RugratArchive'),(3,'1927'),(4,'2Pac'),(5,'42 Dugg'),(6,'50 Cent'),(7,'Aerosmith'),(8,'Afroman'),(9,'AJR'),(10,'Alex Brightman'),(11,'Alicia Keys'),(12,'Amiicus'),(13,'Amir Talai'),(14,'Amy Winehouse'),(15,'Anamanaguchi'),(16,'André 3000'),(17,'Andrea Storm Kaden'),(18,'Andrew Underberg'),(19,'APOCALIPSIS'),(20,'Arctic Monkeys'),(21,'Armut'),(22,'asteria'),(23,'Australian Crawl'),(24,'Axwell'),(25,'Ayparia'),(26,'Azari'),(27,'B.E.R.'),(28,'Baasik'),(29,'Baby Smoove'),(30,'Badfinger'),(31,'Bag Raiders'),(32,'Basement Jaxx'),(33,'Bastille'),(34,'Beach Weather'),(35,'Beastie Boys'),(36,'Beat Saber'),(37,'Becky Hill'),(38,'BigXthaPlug'),(39,'Black Eyed Peas'),(40,'Black Gryph0n'),(41,'Blake Roman'),(42,'Bo Burnham'),(43,'bo en'),(44,'Bonnie Tyler'),(45,'Brando'),(46,'Bring Me The Horizon'),(47,'Bruno Mars'),(48,'Bryan Adams'),(49,'Bryson Tiller'),(50,'Butthole Surfers'),(51,'Caesars'),(52,'Cage The Elephant'),(53,'Calvin Harris'),(54,'Capital Cities'),(55,'Caravan Palace'),(56,'Cardi B'),(57,'Carlos Cid'),(58,'Cavetown'),(59,'Cedric Gervais'),(60,'chart'),(61,'Childish Gambino'),(62,'Chris Brown'),(63,'Christian Borle'),(64,'Christina Aguilera'),(65,'Christine Ebersole'),(66,'CircusP'),(67,'Ck9c'),(68,'Clairo'),(69,'Coldplay'),(70,'Collective Soul'),(71,'Cótiles'),(72,'Cream'),(73,'Creed'),(74,'Creedence Clearwater Revival'),(75,'CreepP'),(76,'Crusher-P'),(77,'Crystal Waters'),(78,'Cults'),(79,'d4vd'),(80,'Daft Punk'),(81,'Dance Fruits Music'),(82,'Daphne Rubin-Vega'),(83,'David Guetta'),(84,'Dayglow'),(85,'DayumDahlia'),(86,'De Staat'),(87,'deadman 死人'),(88,'Dee Mula'),(89,'Depeche Mode'),(90,'Derivakat'),(91,'DigBar'),(92,'Dipsters'),(93,'Dire Straits'),(94,'DJ Fresh'),(95,'DJ Shadow'),(96,'Djo'),(97,'DMX'),(98,'Dr. Dog'),(99,'Dr. Dre'),(100,'Drake'),(101,'DTMX'),(102,'Duke Dumont'),(103,'Duran Duran'),(104,'Dwele'),(105,'Eagles'),(106,'Eagles Of Death Metal'),(107,'Eile Monty'),(108,'Electric Light Orchestra'),(109,'Elizabeth Ann'),(110,'Ellie Goulding'),(111,'Elsie Lovelock'),(112,'Elton John'),(113,'ElyOtto'),(114,'Em Beihold'),(115,'ENHYPEN'),(116,'Erika Henningsen'),(117,'Estelle'),(118,'Eurobeat Brony'),(119,'Evanescence'),(120,'Fall Out Boy'),(121,'fflockk'),(122,'Fleetwood Mac'),(123,'Flo Rida'),(124,'Flume'),(125,'Fontaines D.C.'),(126,'Fort Minor'),(127,'Frank Ocean'),(128,'Frank Sinatra'),(129,'Frankie Valli'),(130,'FrankJavCee'),(131,'Future'),(132,'G Herbo'),(133,'Galantis'),(134,'Ghost'),(135,'Ghost and Pals'),(136,'Ghostface Playa'),(137,'girl in red'),(138,'GloRilla'),(139,'glue70'),(140,'Goodboys'),(141,'Gracie Abrams'),(142,'grandson'),(143,'Green Day'),(144,'Griffinilla'),(145,'Groove Dealers'),(146,'Gunna'),(147,'Guns N\' Roses'),(148,'Haddaway'),(149,'Harmless'),(150,'Harry Styles'),(151,'Hatsune Miku'),(152,'Hilltop Hoods'),(153,'Holy Fuck'),(154,'Hoobastank'),(155,'hoshie star'),(156,'HVME'),(157,'iamjakehill'),(158,'Ice Cube'),(159,'Iggy Pop'),(160,'Imagine Dragons'),(161,'Imogen Heap'),(162,'Jack Stauber\'s Micropop'),(163,'Jagwar Twin'),(164,'James Clarke'),(165,'Jamiroquai'),(166,'Jay Rock'),(167,'JAY-Z'),(168,'Jeremy Jordan'),(169,'Jessica Vosk'),(170,'Jhené Aiko'),(171,'Jimmy Urine'),(172,'Joel Perez'),(173,'John Farnham'),(174,'John Newman'),(175,'Jorge Aguilar II'),(176,'JT Music'),(177,'JubyPhonic'),(178,'Jungle'),(179,'Kaden MacKay'),(180,'Kali Uchis'),(181,'Kanye West'),(182,'Keane'),(183,'Kehlani'),(184,'Keith David'),(185,'Kendrick Lamar'),(186,'Kero Kero Bonito'),(187,'KETTAMA'),(188,'Kevin Foster'),(189,'Keyshia Cole'),(190,'Kid Cudi'),(191,'Kikuo'),(192,'Kimiko Glenn'),(193,'Kings of Leon'),(194,'KISS'),(195,'Kitty'),(196,'Krystal LaPorte'),(197,'Kyary Pamyu Pamyu'),(198,'L Devine'),(199,'Lakeyah'),(200,'Lana Del Rey'),(201,'Latto'),(202,'Lauren Estes'),(203,'Laurie Anderson'),(204,'Laurindo Almeida'),(205,'Le Tigre'),(206,'Lemon Demon'),(207,'Lenny Kravitz'),(208,'Lil Baby'),(209,'Lil Durk'),(210,'Linkin Park'),(211,'Lisa Hannigan'),(212,'Lizz Robinett'),(213,'LongestSoloEver'),(214,'Loud Luxury'),(215,'Lynyrd Skynyrd'),(216,'M.I.A.'),(217,'Mac DeMarco'),(218,'Macklemore'),(219,'Macklemore & Ryan Lewis'),(220,'Macky Gee'),(221,'Mad Tsai'),(222,'MandoPony'),(223,'Måneskin'),(224,'Mariah the Scientist'),(225,'Maroon 5'),(226,'Master Andross'),(227,'Matsushita'),(228,'mazie'),(229,'MEDUZA'),(230,'Melanie Martinez'),(231,'Memphis Cult'),(232,'Men Without Hats'),(233,'MGMT'),(234,'Michael Kovach'),(235,'Michelle Marie'),(236,'Miracle Musical'),(237,'Modjo'),(238,'Mos Def'),(239,'Mother Mother'),(240,'Mötley Crüe'),(241,'My Singing Monsters'),(242,'Nardo Wick'),(243,'Nashimoto Ui'),(244,'Neon Trees'),(245,'New Order'),(246,'Nicole Millar'),(247,'NILFRUITS'),(248,'Nirvana'),(249,'Oliver Tree'),(250,'OneRepublic'),(251,'OR3O'),(252,'Orko'),(253,'Outkast'),(254,'PARTYNEXTDOOR'),(255,'Patina Miller'),(256,'Patricia Taxxon'),(257,'Patti LuPone'),(258,'Peking Duk'),(259,'Penelope Scott'),(260,'Peter McPoland'),(261,'Phantogram'),(262,'Pharmacist'),(263,'PinocchioP'),(264,'Pixies'),(265,'PlayaPhonk'),(266,'Post Malone'),(267,'potsu'),(268,'Queen'),(269,'Radiohead'),(270,'Rainbow'),(271,'Ray Dalton'),(272,'Rebzyyx'),(273,'Red Hot Chili Peppers'),(274,'Reese LAFLARE'),(275,'Regina Spektor'),(276,'Richard Carter'),(277,'Rio Romeo'),(278,'Roar'),(279,'Robbie Williams'),(280,'Roger'),(281,'Rudimental'),(282,'RÜFÜS DU SOL'),(283,'Run The Jewels'),(284,'Ryan Lewis'),(285,'Sam Haft'),(286,'Sarah Stiles'),(287,'Savlonic'),(288,'Scissor Sisters'),(289,'Seph Bentos'),(290,'Shadrow'),(291,'Shoba Narayan'),(292,'Siinamota'),(293,'Simple Minds'),(294,'SNAP!'),(295,'Sodikken'),(296,'Soft Cell'),(297,'Sophie Ellis-Bextor'),(298,'Southside'),(299,'Speelburg'),(300,'SPLYXER'),(301,'Starley'),(302,'Stegosaurus Rex'),(303,'Stephanie Beatriz'),(304,'Steve Angello'),(305,'Steven Universe'),(306,'STOMACH BOOK'),(307,'Stuart Rowe'),(308,'Styles Of Beyond'),(309,'Supermode'),(310,'Swae Lee'),(311,'SZA'),(312,'T-Pain'),(313,'T-Shirt'),(314,'Tally Hall'),(315,'Tame Impala'),(316,'Ted Nugent'),(317,'Teddybears'),(318,'Tevvez'),(319,'Thai McGrath'),(320,'The Animals'),(321,'The Basement Boys'),(322,'The Black Keys'),(323,'The Blake Robinson Synthetic Orchestra'),(324,'The Chainsmokers'),(325,'The Chemical Brothers'),(326,'The Cult'),(327,'The Cure'),(328,'The Dresden Dolls'),(329,'The Game'),(330,'The Glitch Mob'),(331,'The Goo Goo Dolls'),(332,'The Gregory Brothers'),(333,'The Halluci Nation'),(334,'The Irrepressibles'),(335,'The Killers'),(336,'The Living Tombstone'),(337,'The Neighbourhood'),(338,'The Newton Brothers'),(339,'The Rolling Stones'),(340,'The Verve'),(341,'The Weeknd'),(342,'The White Stripes'),(343,'The Who'),(344,'The-Dream'),(345,'Tikkle Me'),(346,'Toby Fox'),(347,'Tom Morello'),(348,'Tom Petty'),(349,'Tommy Richman'),(350,'TomSka'),(351,'Torre Florim'),(352,'Tory Lanez'),(353,'Tove Lo'),(354,'TrackTribe'),(355,'Travis Scott'),(356,'Trey Songz'),(357,'Trippie Redd'),(358,'Tryhardninja'),(359,'Tujamo'),(360,'TV Girl'),(361,'Twenty One Pilots'),(362,'TWISTED'),(363,'Two Door Cinema Club'),(364,'Tyler, The Creator'),(365,'Vacations'),(366,'Vindigo'),(367,'WALK THE MOON'),(368,'Wallows'),(369,'Werdos'),(370,'Will Stetson'),(371,'Woodkid'),(372,'WRABEL'),(373,'Xguiz'),(374,'YK Osiris'),(375,'Young Thug'),(376,'Zombie Nation'),(377,'すいっち');
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 21:40:45
