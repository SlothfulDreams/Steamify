CREATE DATABASE  IF NOT EXISTS `steamify` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `steamify`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: steamify
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `genre_mapping`
--

DROP TABLE IF EXISTS `genre_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre_mapping` (
  `song_genre_id` int NOT NULL,
  `game_genre_id` int NOT NULL,
  PRIMARY KEY (`song_genre_id`,`game_genre_id`),
  KEY `game_genre_id` (`game_genre_id`),
  CONSTRAINT `genre_mapping_ibfk_1` FOREIGN KEY (`song_genre_id`) REFERENCES `song_genre` (`song_genre_id`),
  CONSTRAINT `genre_mapping_ibfk_2` FOREIGN KEY (`game_genre_id`) REFERENCES `game_genre` (`game_genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre_mapping`
--

LOCK TABLES `genre_mapping` WRITE;
/*!40000 ALTER TABLE `genre_mapping` DISABLE KEYS */;
INSERT INTO `genre_mapping` VALUES (2,1),(5,1),(14,1),(15,1),(18,1),(19,1),(22,1),(27,1),(37,1),(38,1),(39,1),(40,1),(51,1),(52,1),(53,1),(55,1),(56,1),(57,1),(61,1),(62,1),(64,1),(65,1),(66,1),(67,1),(70,1),(81,1),(82,1),(83,1),(91,1),(92,1),(103,1),(108,1),(109,1),(110,1),(112,1),(120,1),(121,1),(128,1),(135,1),(8,2),(25,2),(73,2),(84,2),(119,2),(124,2),(134,2),(8,3),(38,4),(1,5),(4,5),(16,5),(20,5),(26,5),(28,5),(32,5),(33,5),(41,5),(42,5),(44,5),(47,5),(50,5),(68,5),(69,5),(74,5),(76,5),(77,5),(94,5),(99,5),(100,5),(114,5),(116,5),(117,5),(126,5),(131,5),(136,5),(78,6),(7,7),(75,8),(94,9),(40,10),(31,11),(59,11),(89,11),(97,11),(113,11),(6,12),(7,12),(9,12),(11,12),(12,12),(23,12),(43,12),(45,12),(46,12),(60,12),(71,12),(72,12),(78,12),(79,12),(80,12),(86,12),(87,12),(88,12),(95,12),(96,12),(98,12),(101,12),(102,12),(104,12),(105,12),(107,12),(111,12),(115,12),(118,12),(123,12),(129,12),(130,12),(69,13),(30,14),(114,15),(29,16),(127,16),(119,17),(30,18),(106,18),(3,19),(13,19),(17,19),(21,19),(34,19),(48,19),(49,19),(58,19),(75,19),(85,19),(90,19),(125,19),(132,19),(133,19),(20,20),(71,21),(10,22),(122,23),(84,24),(24,25),(35,25),(36,25),(54,25),(63,25),(93,25),(122,26);
/*!40000 ALTER TABLE `genre_mapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 21:40:46
