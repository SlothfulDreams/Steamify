CREATE DATABASE  IF NOT EXISTS `steamify` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `steamify`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: steamify
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `song_genre`
--

DROP TABLE IF EXISTS `song_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `song_genre` (
  `song_genre_id` int NOT NULL,
  `song_genre_name` varchar(255) NOT NULL,
  PRIMARY KEY (`song_genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `song_genre`
--

LOCK TABLES `song_genre` WRITE;
/*!40000 ALTER TABLE `song_genre` DISABLE KEYS */;
INSERT INTO `song_genre` VALUES (1,'acid jazz'),(2,'acid rock'),(3,'adult standards'),(4,'alternative dance'),(5,'alternative metal'),(6,'alternative r&b'),(7,'alternative rock'),(8,'anime'),(9,'anti-folk'),(10,'aor'),(11,'art pop'),(12,'art rock'),(13,'avant-garde'),(14,'bass house'),(15,'bassline'),(16,'bedroom pop'),(17,'big band'),(18,'big beat'),(19,'blues rock'),(20,'bossa nova'),(21,'brazilian jazz'),(22,'breakbeat'),(23,'britpop'),(24,'chicago drill'),(25,'christian alternative rock'),(26,'christmas'),(27,'classic rock'),(28,'comedy'),(29,'country rock'),(30,'dark r&b'),(31,'darkwave'),(32,'deep house'),(33,'disco house'),(34,'downtempo'),(35,'drift phonk'),(36,'drill'),(37,'drum and bass'),(38,'dubstep'),(39,'east coast hip hop'),(40,'edm'),(41,'electro'),(42,'electro swing'),(43,'electroclash'),(44,'electronic'),(45,'emo'),(46,'emo rap'),(47,'eurodance'),(48,'exotica'),(49,'experimental'),(50,'french house'),(51,'funk rock'),(52,'future bass'),(53,'g-funk'),(54,'gangster rap'),(55,'garage rock'),(56,'glam metal'),(57,'glam rock'),(58,'glitch'),(59,'gothic rock'),(60,'grunge'),(61,'hard house'),(62,'hard rock'),(63,'hardcore hip hop'),(64,'hardcore techno'),(65,'hardstyle'),(66,'heavy metal'),(67,'hip hop'),(68,'house'),(69,'hyperpop'),(70,'hypertechno'),(71,'indie'),(72,'indie rock'),(73,'j-pop'),(74,'jangle pop'),(75,'jazz'),(76,'k-pop'),(77,'lo-fi'),(78,'lo-fi indie'),(79,'madchester'),(80,'melodic rap'),(81,'metal'),(82,'metalcore'),(83,'modern blues'),(84,'musicals'),(85,'native american music'),(86,'neo soul'),(87,'neo-psychedelic'),(88,'new wave'),(89,'noise rock'),(90,'nu jazz'),(91,'nu metal'),(92,'old school hip hop'),(93,'phonk'),(94,'pop'),(95,'pop punk'),(96,'post-grunge'),(97,'post-hardcore'),(98,'post-punk'),(99,'power pop'),(100,'progressive house'),(101,'proto-punk'),(102,'psychedelic rock'),(103,'psytrance'),(104,'punk'),(105,'queercore'),(106,'quiet storm'),(107,'r&b'),(108,'rap'),(109,'rap metal'),(110,'rap rock'),(111,'riot grrrl'),(112,'rock'),(113,'screamo'),(114,'shibuya-kei'),(115,'shoegaze'),(116,'slap house'),(117,'soft pop'),(118,'soft rock'),(119,'soundtrack'),(120,'southern hip hop'),(121,'southern rock'),(122,'spoken word'),(123,'stoner rock'),(124,'surf rock'),(125,'swing music'),(126,'synthpop'),(127,'synthwave'),(128,'trap'),(129,'trap soul'),(130,'trip hop'),(131,'uk garage'),(132,'vaporwave'),(133,'vocal jazz'),(134,'vocaloid'),(135,'west coast hip hop'),(136,'yacht rock');
/*!40000 ALTER TABLE `song_genre` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 21:40:44
